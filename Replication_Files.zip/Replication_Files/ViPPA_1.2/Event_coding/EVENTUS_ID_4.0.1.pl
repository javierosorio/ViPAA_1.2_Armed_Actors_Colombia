#\uFEFF#
# Identificador de Eventos
# IDEV
#

# Sintaxis:
# perl IDEV_version.pl ACTORES_1 ACTROES_2 VERBOS_1 CORPUS SALIDA_leer SALIDA_codigo

#if (!open(FILE, $ARGV[3])) {print STDERR "archivo CORPUS $ARGV[3] invalido \n";exit(0);}
#if (!open(SALIDA1 , ">AUX1.TMP")) {print STDERR "archivo AUXILIAR no se pudo crear \n";exit(0);}
###Alex, add new hash functionality

print "\n";
print "Welcome to / Bienvenido a \n";
print "\n";
print "************************************************************************\n";
print "\n";
print "EEEEEE	VV  VV	EEEEEE	NN  NN	TTTTTT	UU  UU	SSSSSS	   III DDDD   \n";
print "EEE   	VV  VV	EEE   	NNN NN	  TT  	UU  UU	SSS   	   III DD DDD \n";
print "EEEEEE	 VVVV 	EEEEEE	NNNNNN	  TT  	UU  UU	SSSSSS	== III DD  DD \n";
print "EEE   	 VVVV 	EEE   	NN NNN	  TT  	UUUUUU	   SSS	   III DD DDD \n";
print "EEEEEE	  VV   	EEEEEE	NN  NN	  TT  	 UUUU 	SSSSSS	   III DDDD   \n";
print "\n";
print "************************************************************************\n";
print "\n";

# Press enter
print "\n\n";
print "Press Enter to continue... \n";
print "Teclea Enter para continuar... \n";
$reply = <STDIN>;

print "ENGLISH: \n";
print "Welcome to Eventus ID, v3.9.1\n";
print "\n";
print "Copyright (C) 2014, Javier Osorio and Alejandro Reyes. \n";
print "\n";
print "This program is free software: you can redistribute it and/or modify it under\n";
print "the terms of the GNU General Public License as published by the Free Software\n";
print "Foundation, either version 3 of the License, or any later version.\n";
print "\n";
print "This program is distributed in the hope that it will be useful, but WITHOUT\n";
print "ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS\n";
print "FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.\n";
print "\n";
print "You should have received a copy of the GNU General Public License along with \n";
print "this program. If not, see http://www.gnu.org/licenses/.\n";
print "\n";
print "How to cite this program:\n";
print "Javier Osorio and Alejandro Reyes. 2014. Eventus ID. Version 2.0.\n";
print "\n";
print "\n";

print "\n";
print "************************************\n";
print "\n";

# Press enter
print "\n\n";
print "Press Enter to continue... \n";
print "Teclea Enter para continuar... \n";
$reply = <STDIN>;

print "ESPANOL:\n";
print "Bienvenido a Eventus ID, v3.9.1\n";
print "\n";
print "Copyright (C) 2014, Javier Osorio and Alejandro Reyes \n";
print "\n";
print "Este programa es software libre: usted puede distribuirlo y/o modificarlo bajo\n";
print "los terminos de la Licencia Publica General GNU como esta publicada por el\n";
print "Free Software Foundation, ya sea en la version 3 de la Licencia, o cualquier\n";
print "version posterior. \n"; 
print "\n";
print "Este programa es distribuido con la esperanza que le sea util, pero NO TIENE\n";
print "NINGUNA GARANTIA; ni siquiera la garantia implicita de COMERCIABILIDAD o \n";
print "CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Para mayores detalles, ver la \n";
print "Licencia Publica General GNU. \n";
print "\n";
print "Used debio haber recibido una copia de la Licencia Publica General de GNU junto\n";
print "con este programa. Si no, vea http://www.gnu.org/licenses/.\n";
print "\n";
print "Como citar este programa:\n";
print "Javier Osorio y Alejandro Reyes. 2014. Eventus ID. Version 2.0.\n";
print "\n";
print "\n";

print "\n";
print "************************************\n";
print "\n";

# Press enter
print "\n\n";
print "Press Enter to begin your coding project... \n";
print "Teclea Enter para iniciar tu proyecto de codificacion... \n";
$reply = <STDIN>;

if ($#ARGV >= 0){
	if (!open(FILE_CONFIG , $ARGV[0])) {print STDERR "archivo CONFIG $argv[0] invalido \n";exit(0);}
	#while ($linea = <FILE_CONFIG>){
	#}
	my $actores1 = <FILE_CONFIG>;
	chop($actores1);
	if (!open(FILE_ACTORES1 , $actores1)) {print STDERR "archivo ACTORES $actores1 invalido \n";exit(0);}
	my $actores2 = <FILE_CONFIG>;
	chop($actores2);
	if (!open(FILE_ACTORES2 , $actores2)) {print STDERR "archivo ACTORES $actores2 invalido \n";exit(0);}
	my $verbos = <FILE_CONFIG>;
	chop($verbos);
	if (!open(FILE_VERBOS , $verbos)) {print STDERR "archivo VERBOS $verbos invalido \n";exit(0);}
	my $corpus = <FILE_CONFIG>;
	chop($corpus);
	if (!open(FILE_CORPUS , $corpus)) {print STDERR "archivo CORPUS $corpus no se pudo cargar \n";exit(0);}
	
	my $municipios = <FILE_CONFIG>;
	chop($municipios);
	if ($municipios eq "NA"){
		print "decido no habilitar el reconocimiento de municipios \n";
	}else{
		if (!open(FILE_MUNICIPIOS , "<:encoding(UTF-8)", $municipios)) {print STDERR "archivo MUNICIPIOS $municipios no se pudo cargar \n Si no quiere reconocer municipios poner NA \n";exit(0);}
	}
	
	my $estados = <FILE_CONFIG>;
	chop($estados);
	if ($estados eq "NA"){
		print "decido no habilitar el reconocimiento de estados \n";
	}else{
		if (!open(FILE_ESTADOS , "<:encoding(UTF-8)", $estados)) {print STDERR "archivo ESTADOS $estados no se pudo cargar \n Si no quiere reconocer estados poner NA \n";exit(0);}
	}
	
	my $filtroLugares = <FILE_CONFIG>;
	chop($filtroLugares);
	if ($filtroLugares eq "NA"){
		print "decido no habilitar el filtro de lugares \n";
	}else{
		if (!open(FILE_FILTROLUGARES , "<:encoding(UTF-8)", $filtroLugares)) {print STDERR "archivo FILTRO LUGARES $filtroLugares no se pudo cargar \n Si no quiere reconocer estados poner NA \n";exit(0);}
	}
	
	my $salida = <FILE_CONFIG>;
	chop($salida);
	if (!open(SALIDA1 , ">texto_".$salida)) {print STDERR "archivo SALIDA1 texto_$salida invalido \n";exit(0);}
	#print "\n###### Teclea el nombre del archivo de salida que contendra el codigo de los actores y verbos encontrados.\n";
	if (!open(SALIDA2 , ">codigos_".$salida)) {print STDERR "archivo SALIDA2 codigos_$salida invalido \n";exit(0);}
	print "$actores1 - $actores2 - $verbos - $corpus - $salida\n";
	
	$opcionAlgoritmo = <FILE_CONFIG>;
	#chop($opcionAlgoritmo);
	
}else{
	#1-Abro el archivo de actores
	#2-Abro el archivo de verbos
	print "\n************************************\n";
	print "###### ENG: Enter the file name containg the source actors.\n";
	print "###### ESP: Teclea el nombre del archivo que contiene los actores fuente.\n";
	print "************************************\n";	
	my $actores1 = <STDIN>;
	if (!open(FILE_ACTORES1 , $actores1)) {print STDERR "archivo ACTORES $actores1 invalido \n";exit(0);}
	
	print "\n************************************\n";
	print "###### ENG: Enter the file name containg the target actors.\n";
	print "###### ESP: Teclea el nombre del archivo que contiene los actores objetivo.\n";
	print "************************************\n";	
	my $actores2 = <STDIN>;
	if (!open(FILE_ACTORES2 , $actores2)) {print STDERR "archivo ACTORES $actores2 invalido \n";exit(0);}
	
	print "\n************************************\n";
	print "###### ENG: Enter the file name containg the verbs.\n";
	print "###### ESP: Teclea el nombre del archivo que contiene los verbos.\n";
	print "************************************\n";	
	my $verbos = <STDIN>;
	if (!open(FILE_VERBOS , $verbos)) {print STDERR "archivo VERBOS $verbos invalido \n";exit(0);}
	#if (!open(FILE, $ARGV[3])) {print STDERR "archivo CORPUS $ARGV[3] invalido \n";exit(0);}
	
	print "\n************************************\n";
	print "###### ENG: Enter the file name containg the text corpus.\n";
	print "######      The corpus must have bee generated using Web2Eventus.\n";
	print "###### ESP: Teclea el nombre del archivo que contiene el corpus de texto.\n";
	print "######      El corpus debio haber sido generado utilizando Web2Eventus.\n";
	print "************************************\n";	
	my $corpus = <STDIN>;
	if (!open(FILE_CORPUS , $corpus)) {print STDERR "archivo CORPUS_AUXILIAR $corpus no se pudo cargar \n";exit(0);}
	
	print "\n************************************\n";
	print "###### ENG: Enter the file name containg the municipalities.\n";
	print "###### ESP: Teclea el nombre del archivo que contiene los municipios.\n";
	print "************************************\n";	
	my $municipios = <STDIN>;
	if ($municipios eq "NA"){
		print "decido no habilitar el reconocimiento de municipios \n";
	}else{
		#if (!open(FILE_MUNICIPIOS , "<:encoding(UTF-8)", $municipios)) {print STDERR "archivo MUNICIPIOS $municipios no se pudo cargar \n Si no quiere reconocer municipios poner NA \n";exit(0);}
		if (!open(FILE_MUNICIPIOS , $municipios)) {print STDERR "archivo MUNICIPIOS $municipios no se pudo cargar \n Si no quiere reconocer municipios poner NA \n";exit(0);}
	}
	
	print "\n************************************\n";
	print "###### ENG: Enter the file name containg the states.\n";
	print "###### ESP: Teclea el nombre del archivo que contiene los estados.\n";
	print "************************************\n";		my $estados = <STDIN>;
	if ($estados eq "NA"){
		print "decido no habilitar el reconocimiento de estados \n";
	}else{
		#if (!open(FILE_ESTADOS , "<:encoding(UTF-8)", $estados)) {print STDERR "archivo ESTADOS $estados no se pudo cargar \n Si no quiere reconocer estados poner NA \n";exit(0);}
		if (!open(FILE_ESTADOS , $estados)) {print STDERR "archivo ESTADOS $estados no se pudo cargar \n Si no quiere reconocer estados poner NA \n";exit(0);}
	}
	
	print "\n************************************\n";
	print "###### ENG: Enter the file name containg the location filters.\n";
	print "###### ESP: Teclea el nombre del archivo que contiene los filtros de lugares.\n";
	print "************************************\n";	
	my $filtroLugares = <STDIN>;
	if ($filtroLugares eq "NA"){
		print "decido no habilitar el filtro de lugares \n";
	}else{
		#if (!open(FILE_FILTROLUGARES , "<:encoding(UTF-8)", $filtroLugares)) {print STDERR "archivo FILTRO LUGARES $filtroLugares no se pudo cargar \n Si no quiere reconocer estados poner NA \n";exit(0);}
		if (!open(FILE_FILTROLUGARES , $filtroLugares)) {print STDERR "archivo FILTRO LUGARES $filtroLugares no se pudo cargar \n Si no quiere reconocer estados poner NA \n";exit(0);}
	}
	
	
	print "\n************************************\n";
	print "###### ENG: Enter the name assigned to the output file.\n";
	print "###### ESP: Teclea el nombre asignado para el archivo de salida.\n";
	print "************************************\n";	
	my $salida = <STDIN>;
	if (!open(SALIDA1 , ">texto_".$salida)) {print STDERR "archivo SALIDA1 texto_$salida invalido \n";exit(0);}
	#print "\n###### Teclea el nombre del archivo de salida que contendra el codigo de los actores y verbos encontrados.\n";
	if (!open(SALIDA2 , ">codigos_".$salida)) {print STDERR "archivo SALIDA2 codigos_$salida invalido \n";exit(0);}
	
	
	print "\n###### Teclea el tipo de algoritmo que se usar� para la codificaci�n.";
	print "\n###### 1 - fuente-accion-objetivo\t2 - fuente-accion-objetivo y accion-objetivo.\n";
	
	print "************************************\n";
	print "###### ENG: Select the algorith used for event coding.\n";
	print "######      1 - Only source-action-target.\n";
	print "######      2 - Both source-action-target and action-target.\n";
	print "###### ESP: Selecciona el tipo de algoritmo para codificar eventos.\n";
	print "######      1 - Solo fuente-accion-objetivo.\n";
	print "######      2 - Ambos fuente-accion-objetivo y accion-objetivo.\n";
	print "************************************\n";
	my $opcionAlgoritmo = <STDIN>;

}

##################################################################################
#### 1. LISTA DE ACTORES 1
##################################################################################

$actores001 = "";
print ("<-".$opcionAlgoritmo."->");
print ("\n\n\n\n\n");
$actor_ant="";
while( $l_actores1 = <FILE_ACTORES1> ) {
	chop($l_actores1);
	#chop($l_actores1);
	$l_actores1 =~ s/  / /g;
	$l_actores1 =~ s/  / /g;
	$l_actores1 =~ s/  / /g;
	$l_actores1 =~ s/  / /g;
	$l_actores1 = lc($l_actores1);
	
	#################pregunto que no sea una linea vacia
	if ($l_actores1=~ m/[A-Za-z]/){
		
		###############pregunto si es un actor o es un actor compuesto
		if ($l_actores1 =~ m/^\-/){
			####Actor compuesto
			@partes=split(/ /,$l_actores1);
			
			#Pregunto si el actor sencillo lo agrego al inicio o fin
			if ($partes[1] eq "*"){
				#$lista_actores1{$actor_ant.$partes[2]}=$partes[3];				
				$actores001 = $actores001.'('.$actor_ant.$partes[2].$partes[3].')';
			}else{						
				#$lista_actores1{$partes[1].$actor_ant}=$partes[3];
				$actores001 = $actores001.'('.$partes[1].$actor_ant.$partes[3].')';
			}
		}else{
			####Actor sencillo
			@partes=split(/ /,$l_actores1);
			$actor_ant=$partes[0];
			if ($partes[1] !~ /---/){
				#$lista_actores1{$partes[0]}=$partes[1];
				$actores001 = $actores001.'('.$partes[0].$partes[1].')';
			}else{
				#$lista_filtros{$partes[0]}=$partes[1];
				$actores001 = $actores001.'('.$partes[0].$partes[1].')';
			}
		}#fin else l_actores -
		
	}#Fin de existe algo en la l\u00EDnea
}#fin while

#print ($actores001);
#print ("\n\n\n\n\n");
#exit;

##################################################################################
#### 2. LISTA DE ACTORES 2
##################################################################################

$actores002 = "";
$actor_ant="";
while( $l_actores2 = <FILE_ACTORES2> ) {
	chop($l_actores2);
	#chop($l_actores2);
	$l_actores2 =~ s/  / /g;
	$l_actores2 =~ s/  / /g;
	$l_actores2 =~ s/  / /g;
	$l_actores2 = lc($l_actores2);
	
	#################pregunto que no sea una l\u00EDnea vac\u00EDa
	if ($l_actores2=~ m/[A-Za-z]/){
		
		###############pregunto si es un actor o es un actor compuesto
		if ($l_actores2 =~ m/^\-/){
			####Actor compuesto
			@partes=split(/ /,$l_actores2);
			
			#Pregunto si el actor sencillo lo agrego al inicio o fin
			if ($partes[1] eq "*"){
				#$lista_actores2{$actor_ant.$partes[2]}=$partes[3];
				$actores002 = $actores002.'('.$actor_ant.$partes[2].$partes[3].')';
			}else{						
				#$lista_actores2{$partes[1].$actor_ant}=$partes[3];
				$actores002 = $actores002.'('.$partes[1].$actor_ant.$partes[3].')';
			}
		}else{
			####Actor sencillo
			@partes=split(/ /,$l_actores2);
			$actor_ant=$partes[0];
			#$partes[1]
			if ($partes[1] !~ /---/){
				#$lista_actores2{$partes[0]}=$partes[1];
				$actores002 = $actores002.'('.$partes[0].$partes[1].')';
			}else{
				#$lista_filtros{$partes[0]}=$partes[1];
				$actores002 = $actores002.'('.$partes[0].$partes[1].')';
			}
		}#fin else l_actores -
		
	}#Fin de existe algo en la l\u00EDnea
}

##################################################################################
#### 3. LISTA DE VERBOS
##################################################################################


$verbos001 = "";
$verbo_ant="";
while( $l_verbos = <FILE_VERBOS> ) {
	chop($l_verbos);
	#chop($l_verbos);
	$l_verbos =~ s/  / /g;
	$l_verbos =~ s/  / /g;
	$l_verbos =~ s/  / /g;
	$l_verbos = lc($l_verbos);
	
	#################pregunto que no sea una l\u00EDnea vac\u00EDa
	if ($l_verbos=~ m/[A-Za-z]/){
		
		#Evito agregar verbos que tenga --- que significa que no son admitidos
		#!!!Para mejorar esto, cargar los --- a una lista de t\u00E9rminos a eliminar
		#!!!y al recorrer el corpus, eliminarlos directamente
		#if ($l_verbos !~ /\[---\]/){
			#print $l_verbos."++++++++++++++++\n";
		###############pregunto si es un verbo o es un verbo compuesto
		#########Si empieza (^) con - es compuesto
			if ($l_verbos =~ m/^\-/){
				####Verbo compuesto
				@partes=split(/ /,$l_verbos);
				$l_verbos =~ m/\- (.*) \[/;		#almaceno la palabra entres -  [
				$verbo_comp=$1;
				#print $verbo_comp."--------------\n";
				#print substr($verbo_comp,0,1)."fin \n";
			
				#if ($partes[1] eq "*"){
				if (substr($verbo_comp,0,1) eq "*"){
					$verbo_comp =~ s/\* /$verbo_ant/;
				}else{
					#print substr($verbo_comp,-1,1)."ini \n";
					$verbo_comp =~ s/ \*/$verbo_ant/;
				}
			
				$lista_verbos{$verbo_comp}=$partes[$#partes];
				$verbos001 = $verbos001.'('.$verbo_comp.$partes[$#partes].')';

			}else{
				####Verbo sencillo
				@partes=split(/ /,$l_verbos);
				$verbo_ant=$partes[0];
				$lista_verbos{$partes[0]}=$partes[1];
				$verbos001 = $verbos001.'('.$partes[0].$partes[1].')';
			}#fin else l_verbos -
		
		#}else{
		#		#lista con no compuestos
		#		@partes=split(/ /,$l_verbos);
		#		$lista_filtros{$partes[0]}=$partes[1];
		#		$verbos001 = $verbos001.'('.$partes[0].$partes[1].')';
		#	}
		
	}#Fin de existe algo en la l\u00EDnea
}

##################################################################################
#### 4. LISTA DE MUNICIPIOS
##################################################################################


while ($l_municipios=<FILE_MUNICIPIOS>){
  chop($l_municipios);
  @archivo=split(/\t/,$l_municipios);

	$archivo[1]=~s/\u00E1/a/g;	$archivo[1]=~s/\u00E9/e/g;	$archivo[1]=~s/\u00ED/i/g;
	$archivo[1]=~s/\u00F3/o/g;	$archivo[1]=~s/\u00FA/u/g;
	$archivo[1]=~s/\u00C1/A/g;	$archivo[1]=~s/\u00C9/E/g;	$archivo[1]=~s/\u00CD/I/g;
	$archivo[1]=~s/\u00D3/O/g;	$archivo[1]=~s/\u00DA/U/g;
	$archivo[1]=~s/\u00F1/nn/g;	$archivo[1]=~s/\u00D1/NN/g;
	$archivo[1] = lc($archivo[1]);

	#si el nombre tiene varios codigos los agrego.
		# Uso "u" para municipios
	if ( exists $l_mun{"$archivo[1]"} == 1){
		$l_mun{"$archivo[1]"}=$l_mun{"$archivo[1]"}.","."u-$archivo[0]";
	}else{
		$l_mun{"$archivo[1]"}="u-$archivo[0]";
	}
	$l_mun_tam{"$archivo[1]"}=length($archivo[1]);
	$l_cod{"$archivo[0]"}=$archivo[1];
	
}

##################################################################################
#### 5. LISTA DE ESTADOS
##################################################################################


while ($l_estados=<FILE_ESTADOS>){		
  chop($l_estados);
  @archivo=split(/\t/,$l_estados);
  
	$archivo[1]=~s/\u00E1/a/g;	$archivo[1]=~s/\u00E9/e/g;	$archivo[1]=~s/\u00ED/i/g;
	$archivo[1]=~s/\u00F3/o/g;	$archivo[1]=~s/\u00FA/u/g;
	$archivo[1]=~s/\u00C1/A/g;	$archivo[1]=~s/\u00C9/E/g;	$archivo[1]=~s/\u00CD/I/g;
	$archivo[1]=~s/\u00D3/O/g;	$archivo[1]=~s/\u00DA/U/g;
	$archivo[1]=~s/\u00F1/nn/g;	$archivo[1]=~s/\u00D1/NN/g;
	$archivo[1] = lc($archivo[1]);

#si el nombre tiene varios c\u00F3digos los agrego.
		# Uso "e" para estados
		#print "$archivo[1]\t";
	if ( exists $l_mun{"$archivo[1]"} ){
		#print "exist $archivo[1]\t";
		$l_mun{"$archivo[1]"}=$l_mun{"$archivo[1]"}.","."e-$archivo[0]";
		#print $l_mun{"$archivo[1]"}."\t";
	}else{
		$l_mun{"$archivo[1]"}="e-$archivo[0]";
	}
	$l_mun_tam{"$archivo[1]"}=length($archivo[1]);
	$l_cod{"$archivo[0]"}=$archivo[1];
	$l_estados=$l_estados."$archivo[1]|";

}
chop($l_estados);
$l_estados=~s/\./\\\./g;
$l_estados="[$l_estados]";

##################################################################################
#### 6. LISTA DE FILTROS DE UBICACION
##################################################################################


while ($l_filtrolug=<FILE_FILTROLUGARES>){		
  chop($l_filtrolug);
  @archivo=split(/\t/,$l_filtrolug);
  
	$archivo[1]=~s/\u00E1/a/g;	$archivo[1]=~s/\u00E9/e/g;	$archivo[1]=~s/\u00ED/i/g;
	$archivo[1]=~s/\u00F3/o/g;	$archivo[1]=~s/\u00FA/u/g;
	$archivo[1]=~s/\u00C1/A/g;	$archivo[1]=~s/\u00C9/E/g;	$archivo[1]=~s/\u00CD/I/g;
	$archivo[1]=~s/\u00D3/O/g;	$archivo[1]=~s/\u00DA/U/g;
	$archivo[1]=~s/\u00F1/nn/g;	$archivo[1]=~s/\u00D1/NN/g;
	$archivo[1]=~s/�/a/g;				$archivo[1]=~s/�/e/g;				$archivo[1]=~s/�/i/g;
	$archivo[1]=~s/�/o/g;				$archivo[1]=~s/�/u/g;				
	$archivo[1] = lc($archivo[1]);

	#Pongo el filtro en la misma lista de filtros de actores y verbos
	#if ($archivo[1] eq "0"){
	#	print $archivo[1]."\n";
	#	print $l_filtrolug."\n";
	#	exit;
	#}
	$lista_filtros{"$archivo[1]"}="0";
	$lista_filtros_tam{"$archivo[1]"}=length($archivo[1]);
}

####Para comprobar la lista hash de actores
#foreach my $key (keys %lista_actores){
#	print "$key = $lista_actores{$key}\n";
#}
####Para comprobar la lista hash de verbos
#foreach my $key (keys %lista_verbos){
#	print "$key = $lista_verbos{$key}\n";
#}
#foreach my $key (keys %lista_filtros){
#print "$key = $lista_filtros{$key}\n";
#}
#exit;
#foreach my $key (keys %l_mun){
#print "$key = $l_mun{$key}\n";
#}
#exit;

$idAnterior = "";
$estadosEncontrados = "";
$municipiosEncontrados = "";
$estadosCodEncontrados = "";
$municipiosCodEncontrados = "";
%estadosHash1 = ();
%municipiosHash1 = ();
@resultSVS = (1 .. 100);
$iResults = 0;

##################################################################################
#### 7. LEER EL CORPUS
##################################################################################

# Carga linea por linea del corpus
while( $l_corpus = <FILE_CORPUS> ) {
	chop($l_corpus);
	#quito espacios en blanco
	$l_corpus =~ s/  / /g;
	$l_corpus =~ s/  / /g;
	$l_corpus =~ s/  / /g;	
	
	######################################
	#separo la noticia de su identificador
	@partes=split(/\|/,$l_corpus);
	@identificador=split(/\t/,$partes[0]);
	@idNota=split(/_/,$identificador[1]);
	
	#print $partes[0]."\t".$estadosEncontrados."\n";
	print $identificador[1]."\n";
	#print $idNota[0]."\n";
	
	$estadosEncontrados =~ s/\\//g;
	$municipiosEncontrados =~ s/\\//g;
	
	# Verifico si estoy en la misma nota
	if ($idNota[0] ne $idAnterior){
		print "\n:::::Change note::::\n";
	
		# Despues de cambiar de nota, imprimo los elementos que habia encontrado
		if ($iResults > 0){
			for (my $i=0; $i<$iResults; $i++){
				#print $resultSVS[$i]."States_i".$estadosEncontrados."\tCounties_i".$municipiosEncontrados."\n";
				@countElements = split(/\t/,$resultSVS[$i]);
				# Si tengo mas de seis elementos, es que esta completo (con edo y mun), no agrego nada e imprimo salida 1 (texto) salida 2 (codigos)
				if ($#countElements > 6){
					print	SALIDA1 $resultSVS[$i]."\n";
					@partCode = split(/\t/,$resultSVS[$i]);					
					@st_and_ct = split(/States/,$resultSVS[$i]);
				}
				# Si no tengo mas de seis elementos, agrego los estados y municipios que aparecieron durante la nota, e imprimo salida 1 (texto) salida 2 (codigos)
				else{
					print	SALIDA1 $resultSVS[$i]."States".$estadosEncontrados."\tCounties".$municipiosEncontrados."\n";					
					$newString = $resultSVS[$i]."States".$estadosEncontrados."\tCounties".$municipiosEncontrados;
					@partCode = split(/\t/,$newString);	
					@st_and_ct = split(/States/,$newString);
				}
				
				@act1Code = split(/\[/,$partCode[2]);
				$act1Code[1] =~ s/\].*//;
				@verbCode = split(/\[/,$partCode[3]);
				$verbCode[1] =~ s/\].*//;
				@act2Code = split(/\[/,$partCode[4]);
				$act2Code[1] =~ s/\].*//;
				
				@stateNum = split(/Counties/,$st_and_ct[1]);
				$stateNum[0] =~ s/\t//g;
				$stateNum[0] =~ s/\-.*//g;
				@cityCodes = ($stateNum[1] =~ m/(\d+)/g);
				$cityCodesAll = "";
				foreach $cityCode(@cityCodes){
					$cityCodesAll = $cityCodesAll.$cityCode."\t";
				}					
				
				print	SALIDA2 $partCode[0]."\t".$partCode[1]."\t".$act1Code[1]."\t".$verbCode[1]."\t".$act2Code[1].
							"\tStates\t".$stateNum[0]."\tCounties\t".$cityCodesAll."\n";
			}
		}
			
		%estadosHash1 = ();
		%municipiosHash1 = ();
		$estadosEncontrados = "";
		$municipiosEncontrados = "";
		$estadosCodEncontrados = "";
		$municipiosCodEncontrados = "";
		$idAnterior = $idNota[0];
		$iResults = 0;
	}
	######################################
	#convierto todo a minusculas y las guardo en "texto"
	$texto = lc($partes[1]);
	$texto =~ s/\d . \d/ /g;
	#$texto =~ s/\d\.\d/ /g;
	#print $texto;
	
	###Elimino del corpus las palabras con [---] de la lista de filtros de lugares
	foreach my $key (keys %lista_filtros){
	
		$frase_eliminar = $key;
		#$frase_eliminar = "8\/a \. zona militar";
		$frase_eliminar =~ s/_/ /g;
		$frase_eliminar =~ s/\./\\\./g;
		$frase_eliminar =~ s/\//\\\//g;
		
		#if ($frase_eliminar =~ m/^8/){
			#print $frase_eliminar."\n";
			#$frase_eliminar = "8\/a \. zona militar";
		#}
		
		#if ($texto =~ /$frase_eliminar/){
		#	print "Eliminar "."$frase_eliminar = $lista_filtros{$key}\n";
		#}
		$texto =~ s/$frase_eliminar/ /g;
		#$texto =~ s/$arr_mpos_name[$i]/ /g;
	}
	#print $texto;
	
	#Busco si en el texto existe alg�n municipio
		#OJO, esto codifica municipios y estados (no fechas)
	# Si si, lo pongo en la lista de lugares
	#############################################						
	$listaLugares = subEncuentraFechas($texto);					
	@lugares=split(/\,/,$listaLugares);						
	############################################
	#print $texto;
	
	#############################################
	## 
	#############################################
	
	print "$texto\n\n";
	#separo cada una de las palabras y las meto en el arreglo de "palabras"
	@palabras=split(/ /,$texto);
	
	#### DEFINO VARIABLES NECESARIAS	
	#$i_pal es el indice de la palabra en el texto	
	@actors_and_verbs = ();
	$isFirstActor = 1;
	$lastIActor = 0;
	$lastIVerb = 0;
	
	#####################################################################################
	#####################################################################################
	### Recorre cada una de las palabras de la noticia y guarda actores y verbos
	#####################################################################################
	#####################################################################################
	
	$last_big_index1 = 0; $last_big_index2 = 0;
	# Inicia for palabras noticia
	for ($i_pal=0; $i_pal<$#palabras; $i_pal++){
		
		#print "\nPalabra: <".$palabras[$i_pal].">".$i_pal."\n";		
		##Search for Actors 1 or 2
		
		#####################################################################################
		## Corro la funcion "existNamedEntity"
		## Verifica si hay una entidad que inicie con la palabra actual, y si si, la regresa
		#####################################################################################
		$found = 0;
		$morBigIndex = 0;
		($morBigLength,$morBigIndex,$morBigPhrase) = existNamedEntity($isFirstActor);	
		print "\nBighrase ".$morBigPhrase."Index $morBigIndex ipal $i_pal\n";		
		if ($morBigLength>0 && $morBigIndex > $lastIActor){			
			
			# Si lo que regresa "existNamedEntity" es diferente a "---", entonces lo mando al allreglo "actors_and_verbs"
			# Pero para actores "A-"
			if ($morBigPhrase !~ /---/){
				if ($isFirstActor == 1){
					push @actors_and_verbs, "A-".$morBigPhrase;
				}else{
					push @actors_and_verbs, "A-".$morBigPhrase;
					$isFirstActor = 1;
					$isComplete = 1;
				}
			}else{
				#print "Filtro ".$morBigPhrase."\t";
			}
			$lastIActor = $morBigIndex;
		}
		
		if ($i_pal < $morBigIndex){
			$found = 1;
			$last_big_index1 = $morBigIndex;
		}
		
		##Search for Verbs using the same function "existNamedEntity" but with value "2"
		($morBigLength,$morBigIndex,$morBigPhrase) = existNamedEntity(2);	
		print "\nBighrase ".$morBigPhrase."Index $morBigIndex ipal $i_pal\n";
		if ($morBigLength>0 && $morBigIndex > $lastIVerb){
			#print $morBigPhrase."\t\t";
			if ($morBigPhrase !~ /---/){
			# Si lo que regresa "existNamedEntity" es diferente a "---", entonces lo mando al allreglo "actors_and_verbs"
			# Pero para verbos "V-"
				push @actors_and_verbs, "V-".$morBigPhrase;
			}else{
				#print "Filtro ".$morBigPhrase."\t";
			}
			$lastIVerb = $morBigIndex;			
		}		
		
		if ($i_pal < $morBigIndex){
			$found = 1;
			$last_big_index2 = $morBigIndex;
		}		
		
		if ($found == 1){
		if ( $last_big_index2 > $last_big_index1 ){
			$i_pal = $last_big_index2-1;
		}else{
			$i_pal = $last_big_index1-1;
		}
		}else{
		
		if ($palabras[$i_pal] eq '.'){
			push @actors_and_verbs, ".";
		}
		}
		
		
			
	} #fin for palabras noticia	

	print "@actors_and_verbs"."\n\n";
	
	
	#####################################################################################
	#####################################################################################
	### Crea combinaciones de actores y verbos
	#####################################################################################
	#####################################################################################
	
	# Genero arreglos a utilizar
	@actors001Found = ();
	@actors002Found = ();
	@verbs001Found = ();
	# Defino variables a utilizar
	$isComplete = 0;
	# Defino "isFirstActor" igual a 1 para "fuente" y 0 para "target"
	# Asumo que siempre inicio buscando el actor "fuente" (1)
	$isFirstActor = 1;	
	
	# Para cada elemento del arreglo de "actors_and_verbs"
	# pregunto si es actor (A) o verbo (V)
	# y armo las combinaciones
	foreach $newPal(@actors_and_verbs){
	
	    #print $newPal."\n";
		if ($newPal eq '.'){
		
			#print 'punto \t'.scalar(@actors001Found)." \t".scalar(@verbs001Found)."\n";
		
			# Crea arreglo de A-V sin target	
			#print "\nScalar: ".scalar(@actors001Found)." --- ".scalar(@verbs001Found)."\n";
			if (scalar(@actors001Found) > 0 && scalar(@verbs001Found) > 0 && $opcionAlgoritmo==2){
				my $firstVerb = shift @verbs001Found;
				while(@actors001Found){
					my $firstAct = shift @actors001Found;
					#print $firstAct." ".$firstVerb."\n";
					addActVerbActToArray($iResults,$partes[0],$firstAct,$firstVerb,"",$lugares[2],$lugares[0]);
					$iResults++;				
				}
			}
			
			# Crea actor solo
			if ( scalar(@actors001Found) > 0 && $opcionAlgoritmo==2){
				while(@actors001Found){
					my $firstAct = shift @actors001Found;
					#print "\n".$actors001Found[0]."| ";
					addActVerbActToArray($iResults,$partes[0],$firstAct,"","",$lugares[2],$lugares[0]);
					$iResults++;
				}
			}
		
			
			# Genero arreglos a utilizar
			@actors001Found = ();
			@actors002Found = ();
			@verbs001Found = ();
			# Defino variables a utilizar
			$isComplete = 0;
			# Defino "isFirstActor" igual a 1 para "fuente" y 0 para "target"
			# Asumo que siempre inicio buscando el actor "fuente" (1)
			$isFirstActor = 1;
		}else{		
			# El arreglo "tipo" identifica si es Actor o Verbo
			@tipo = split(/\-/,$newPal);
			
			# Si el elemento es un actor (A) y estoy buscando un target (0), entro a la condicion:
			if ($tipo[0] eq 'A' && $isFirstActor == 0){
				## Esta condicion sirve para crear dos combinaciones: A-V-A or V-A
				my $firstVerb = shift @verbs001Found;
					# shift saca el primer verbo del arreglo y lo mete en la variable
				if ( scalar(@actors001Found) > 0 ){
					#print "Create A-V-A\n";
					while(@actors001Found){
						my $firstAct = shift @actors001Found;
						# shift saca el primer actor del arreglo y lo mete en la variable
						#print $firstAct." ".$firstVerb."\n";			
						addActVerbActToArray($iResults,$partes[0],$firstAct,$firstVerb,$tipo[1],$lugares[2],$lugares[0]);
						$iResults++;				
					}
				}else{
					#print "Create V-A\n";
					if ($opcionAlgoritmo==2){
						addActVerbActToArray($iResults,$partes[0],"",$firstVerb,$tipo[1],$lugares[2],$lugares[0]);
						$iResults++;
					}
				}	
				$isFirstActor = 1;
			} # Termino condicion del target
			
			# Si es un actor y estoy buscando la "fuente" (1)
			# Verifico que sea un actor (A),  si si, lo meto a "actors001Found"
			elsif ($tipo[0] eq 'A'){			
					#print "\nnew\t".$tipo[1]."\t";
					# Si es actor (A), lo meto al arreglo de actores encontrados "actors001Found"
					push @actors001Found, $tipo[1];				
			}
			# Si no es actor (A), es un verbo (V)
			# Si encontramos un verbo y lo que buscabamos era un target, 
			# entonces hago combinacion A-V utilizando los elementos anteriores 
			elsif ($tipo[0] eq 'V' && $isFirstActor == 0){
				#print all Act-Verb
				# Esta condicion sirve para crear la combinacion A-V
				my $firstVerb = shift @verbs001Found;
				while(@actors001Found){
					my $firstAct = shift @actors001Found;
					#print $firstAct." ".$firstVerb."\n";
					if ($opcionAlgoritmo==2){
						addActVerbActToArray($iResults,$partes[0],$firstAct,$firstVerb,"",$lugares[2],$lugares[0]);
						$iResults++;
					}			
				}
				# 
				push @verbs001Found, $tipo[1];
			
			}elsif ($tipo[0] eq 'V'){
				# print "\npush Verb\n";	
				# Si es verbo (V) lo meto al arreglo de verbos encontrados "verbs001Found"
				push @verbs001Found, $tipo[1];
				# Si ya enontre un verbo, genero bandera para indicar que tengo que buscar "target" (0)
				$isFirstActor = 0;
			}	
		} # Inicio la busqueda de un "target", vamos para arriba			
			
			
		
		
		#exit;
	}
	
	# Crea arreglo de A-V sin target	
		#print "\nScalar: ".scalar(@actors001Found)." --- ".scalar(@verbs001Found)."\n";
		if (scalar(@actors001Found) > 0 && scalar(@verbs001Found) > 0 && $opcionAlgoritmo==2){
			my $firstVerb = shift @verbs001Found;
			while(@actors001Found){
				my $firstAct = shift @actors001Found;
				#print $firstAct." ".$firstVerb."\n";
				addActVerbActToArray($iResults,$partes[0],$firstAct,$firstVerb,"",$lugares[2],$lugares[0]);
				$iResults++;				
			}
		}
		
		# Crea actor solo
		if ( scalar(@actors001Found) > 0 && $opcionAlgoritmo==2){
			while(@actors001Found){
				my $firstAct = shift @actors001Found;
				#print "\n".$actors001Found[0]."| ";
				addActVerbActToArray($iResults,$partes[0],$firstAct,"","",$lugares[2],$lugares[0]);
				$iResults++;
			}
		}
	
	$l_corpus_ant = $l_corpus;
}


#####################################################################################
### FUNCIONES
#####################################################################################
sub addActVerbActToArray{
	my $iRes = $_[0];
	my $data = $_[1];
	my $act1 = $_[2];
	my $verb = $_[3];
	my $act2 = $_[4];
	my $stat = $_[5];
	my $city = $_[6];
	
	#two_leaders_in_an_ontario_street_gang_[0000000]
	# Formatea la informacion de actores y verbos (segun existan) 
	if (length($act1) > 0){
		my @act1A = split(/\[/,$act1); 
		$act1 = "A1.-[$act1A[1] = $act1A[0]";
	}
	if (length($verb) > 0){
		my @verbA = split(/\[/,$verb); 
		$verb = "V1.-[$verbA[1] = $verbA[0]";
	}
	if (length($act2) > 0){
		my @act2A = split(/\[/,$act2); 
		$act2 = "A2.-[$act2A[1] = $act2A[0]";
	}
	
	######################################################
	# Genera agrego para imprimir (agrega ciudades y estados si es que hay)
	if(length($city)>0 || length($stat) > 0){
		#$resultSVS[$iRes] = $data."\tA1.-[$act1A[1] = $act1A[0]\tV1.-[$verbA[1] = $verbA[0]\tA2.-[$act2A[1] = $act2A[0]\tStates".$stat."\tCounties\t".$city;
		$resultSVS[$iRes] = $data."\t".$act1."\t".$verb."\t".$act2."\tStates".$stat."\tCounties\t".$city;
	}else{
		$resultSVS[$iRes] = $data."\t".$act1."\t".$verb."\t".$act2."\t";
	}
	
}


###########################################################################
## FUNCION "existNamedEntity" VERIFICA SI EXISTE ENTIDAD NOMBRADA Y SI SI, LA REGRESA
###########################################################################
##opc 0 = Search for Actor 2
##opc 1 = Search for Actor 1
##opc 2 = Search for Verb
sub existNamedEntity{
	my $opc = $_[0];
	my $morBigPhrase = "";
	my $morBigLength = 0;
	my $morBigIndex = 0;
	
	# Carga el contenido de la lista de (A1, A2, V) que empata con la primera palabra
	# y las guarda en el arreglo "newPalabras"
		# Esta es la parte que hace el corpus caprichoso
	if    ($opc == 1){
		@newPalabras = ($actores001 =~ m/\(($palabras[$i_pal]_.*?\[.*?\])/g);
	}elsif($opc == 0){
		@newPalabras = ($actores002 =~ m/\(($palabras[$i_pal]_.*?\[.*?\])/g);
	}elsif($opc == 2){
		@newPalabras = ($verbos001  =~ m/\(($palabras[$i_pal]_.*?\[.*?\])/g);
	}else{
		print "Error in existNamedEntity Invalid Optiton";
	}
	
	#print "@newPalabras"."\n\n";
	foreach $newPal(@newPalabras){
	#Check if the newPal match with the rest of the letter		
		my $newI = 1;
		my $exist = 1;
		#print "pal ".$newPal."\t";
		## Separo las palabras por "_" y las guardo en el arreglo "newPalExp"
		my @newPalExp = split(/_/,$newPal);	

        # Inicia el while del exist	de la primera palabra del arreglo "newPalExp" de palabras
		while($exist){
			# Verifico si la siguiente parabra del arreglo "newPalExp" coincide con la siguiente palabra de la linea del corpus	
			# Si si, sigue agregando ++, si no, se va a else
			if ($newPalExp[$newI] eq $palabras[$i_pal+$newI]){			
				$newI++;
			}else{
				# Verifico si llegue al fin de entidad nombrada e inicio del codigo con []
				## OJO, el codigo debe ser numerico!!!!
				if ($newPalExp[$newI] =~ m/\[\d+\]/){
					#print $newPal."\n";
					if ( length($newPal) > $morBigLength ){
						# Cuento la longitud de "newPal" para priorizar las palabras mas largas
						$morBigLength = length($newPal);
						# Redefine "newPal" como "morBigPhrase"
						$morBigPhrase = $newPal;
						# Genera el indice de la ultima palabra procesada
						$morBigIndex = $i_pal+$newI;
					}						
				}elsif($newPalExp[$newI] =~ /---/){
					#print "$newPal Filtro\n";
					# Si el codigo en [] no es numerico, entoces es ---
					# 
					$morBigLength = length($newPal);
					$morBigPhrase = "---";
					$morBigIndex = $i_pal+$newI;
				}
				$exist = 0;
				last;
			}
		} # Termina el while de exist
	} # Temina for eaech de las palabras del corpus y la lista de entidades (A1, A2, V)
	
	# REGRESA LOS VALORES ENCONTRADOS (palabra mas grande, indice final y longitud)
	return($morBigLength, $morBigIndex, $morBigPhrase);
}


######################Subrutina para buscar fechas
sub subEncuentraFechas{
	my ($var) = @_;
	#print $texto."\n";
	
	$linea = $var;
						
  @arr_edos=();
  @arr_edos_name=();
  @arr_mpos=();
  @arr_mpos_name=();
  $i_edos=0;
  $i_mpos=0;
  $entro=0;
  #recorro estados y municipios
	foreach my $key (sort {$l_mun_tam{$b} <=> $l_mun_tam{$a}} keys %l_mun_tam){
	
		$value = $l_mun{$key};
      
		#agrego una \ antes de los . para que el punto no se confunda
		$key2=$key;
		$key=~s/\./\\\./g;							
      
		$peq_valida = 1;
		if ( (length($key)<=3) && ($linea =~ / $key /) && ($linea !~ /| $key /) ){
			$peq_valida= 1;
			print "una peque�a";
		}
      				
		#esta instruccion acepta son sin etc ...
		if ( ($linea =~ / $key /i) && ( ($peq_valida == 1) || (length($key)>=4) ) ){
			#print "EXISTEEEEEEEEEEE ALGOOOOOOOOOOOOOO\n";
			#if ($key == "pue"){
			#	print SALIDA "-".$key."-";
			#}
			$positivo=0;
			$negativo=0;
			$remplazo="";

							if ($linea =~ / Ciudad de $key/i){ $positivo=1; 	$remplazo="Ciudad de $key";}
							if ($linea =~ / Ciudad $key/i){ $positivo=1; 		$remplazo="Ciudad $key";}
							if ($linea =~ / Estado de $key/i){ $positivo=2; 	$remplazo="Estado de $key";}
							if ($linea =~ / Municipio de $key/i){ $positivo=1; 	$remplazo="Municipio de $key";}

							if ($linea =~ /Originario de $key/i){ $negativo=1;	$remplazo="Originario de $key"; }
							if ($linea =~ /Originario del $key/i){ $negativo=1;	$remplazo="Originario del $key"; }
							#if ($linea =~ /Procedente de \Q$key\E/i){ $negativo=1;	$remplazo="Procedente de $key"; }

							if ($linea =~ /Originarios de $key/i){ $negativo=1;	$remplazo="Originarios de $key"; }
							if ($linea =~ /Originarios del $key/i){ $negativo=1;	$remplazo="Originarios del $key"; }
							if ($linea =~ /Procedentes de $key/i){ $negativo=1;	$remplazo="Procedentes de $key"; }
							#if ($linea =~ /Con destino a \Q$key\E/i){ $negativo=1; 	$remplazo="Con destino a $key";}

							if ($linea =~ /Gobierno de $key/i){ $negativo=1; 	$remplazo="Gobierno de $key";}
							if ($linea =~ /Gobierno del Estado de $key/i){ $negativo=1; 	$remplazo="Gobierno del Estado de $key";}
							if ($linea =~ /Gobernador de $key/i){ $negativo=1; 	$remplazo="Gobierno de $key";}
							if ($linea =~ /Gobernador del Estado de $key/i){ $negativo=1; 	$remplazo="Gobernador del Estado de $key";}
							if ($linea =~ /Justicia del Estado de $key/i){ $negativo=1; 	$remplazo="Justicia del Estado de $key";}

							if ($linea =~ /Seguridad de $key/i){ $negativo=1; 	$remplazo="Seguridad de $key";}
							if ($linea =~ /Publica de $key/i){ $negativo=1; 	$remplazo="Publica de $key";}
							if ($linea =~ /Seguridad del Estado de $key/i){ $negativo=1; 	$remplazo="Seguridad del Estado de $key";}
							if ($linea =~ /Publica del Estado de $key/i){ $negativo=1; 	$remplazo="Publica del Estado de $key";}

							if ($linea =~ /Estado de Derecho $key/i){ $negativo=1; 	$remplazo="Estado de Derecho $key";}

							if ($linea =~ /Con placas de $key/i){ $negativo=1; 	$remplazo="Con placas de $key";}
							if ($linea =~ /Con placas del Estado de $key/i){ $negativo=1; 	$remplazo="Con placas del Estado de $key";}


				$remplazo2=$remplazo;
				$remplazo2=~s/ /_/g;

				#Si encuentro un remplazo negativo lo elimino
				if ($negativo == 1){
					#print "NEGATIVOOOOO\n";
					#printf "Estado a reemplazar: ". $l_estados."\n";
	    		#if ($linea =~ /$remplazo[,|.| ] $l_estados/i){
	      		#$linea_archivo =~ s/($remplazo[,|.| ] $l_estados)/<Filtro>$1<\/Filtro>/gi;
	      		#$linea =~ s/($remplazo[,|.| ] $l_estados)/<Filtro>$1<\/Filtro>/gi;
				if ($linea =~ /$remplazo[,|.| ] $key/i){
	      		$linea_archivo =~ s/($remplazo[,|.| ] $key)/<Filtro>$1<\/Filtro>/gi;
	      		$linea =~ s/($remplazo[,|.| ] $key)/<Filtro>$1<\/Filtro>/gi;
	    		}else{
	      		$linea_archivo =~ s/$remplazo/<Filtro>$remplazo2<\/Filtro>/gi;
	      		$linea =~ s/$remplazo/<Filtro>$remplazo2<\/Filtro>/gi;
	    		}
				}elsif ($positivo == 1){
					#print "MUNICIPIOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO\n";
	    		$linea_archivo =~ s/$remplazo/<mun_$value>$remplazo2<\/mun>/gi;
	    		$linea =~ s/$remplazo/<mun_$value>$remplazo2<\/mun>/gi;
					#$value=~s/u\-//g;
					@codigos=split(/\,/,$value);
					foreach $codigo(@codigos){
			  		if ($codigo=~/u/){
			    		$codigo=~s/u\-//;
			    		$arr_mpos[$i_mpos]=$codigo;
			    		$arr_mpos_name[$i_mpos]=$key;
			    		$i_mpos++;
			  		}
					}
				}elsif ($positivo==2)
				{#Si es un estado
					#print "ESTADOOOOOOOOOOOOOOOOOOOOOOOOOO\n";
					$linea_archivo =~ s/$remplazo/<edo_$value>$remplazo<\/edo>/gi;
			
					@codigos=split(/\,/,$value);
					foreach $codigo(@codigos){
					if($codigo=~/e\-/){
						$codigo=~s/e\-//g;
						$arr_edos[$i_edos]=$codigo;
						$arr_edos_name[$i_edos]=$key;
						$i_edos++;
						}
					}
				}else
				{
              	    	#preguntar si tiene varias opciones
					#print "Aquiiiii  \t ";
					@codigos=split(/\,/,$value);
					foreach $codigo(@codigos){
						#print "Aqui \t $codigo \n";
						if ($codigo=~/u/){
								$codigo=~s/u\-//;
								$arr_mpos[$i_mpos]=$codigo;
								$arr_mpos_name[$i_mpos]=$key;
								$i_mpos++;
						}else{
								$codigo=~s/e\-//;
								$arr_edos[$i_edos]=$codigo;
								$arr_edos_name[$i_edos]=$key;
								$i_edos++;
						}
					}
					$value=~s/u\-//g;	$value=~s/e\-//g;
		
					#$linea_archivo =~ s/$key\./<lugar_$value>$key2<\/lugar>\./gi;
					#$linea_archivo =~ s/$key /<lugar_$value>$key2<\/lugar> /gi;
					#$linea_archivo =~ s/$key\,/<lugar_$value>$key2<\/lugar>\,/gi;
		
					$linea=~s/ $key\./ /gi;	$linea=~s/ $key / /gi;	$linea=~s/ $key\,/ /gi;
					#imprime el nombre del mpo o edo y su c\u00F3digo
					#print $key2."\t$value\t";
				}					
		}
	}#fin for each key
						
						$l_edos_encontrados="";
						$l_edos_encontrados_cod="";
						my %hash1 = ();
						for ($i=0; $i<$i_edos; $i++){
							#$l_edos_encontrados=$l_edos_encontrados."|".$l_cod{$arr_edos[$i]};
							if (! exists $estadosHash1{$arr_edos[$i]}){
								$estadosEncontrados = $estadosEncontrados."\t".$arr_edos[$i]."-".$arr_edos_name[$i];
								print $arr_edos_name[$i];
								$texto =~ s/$arr_edos_name[$i]/ /g;
								#print $texto;
								$estadosCodEncontrados = $estadosCodEncontrados."\t".$arr_edos[$i];
								$estadosHash1{$arr_edos[$i]}="ok";
								#print "\tEdo: ". $arr_edos_name[$i]."\t".$arr_edos[$i]."\t";
							}
							
							if (! exists $hash1{$arr_edos[$i]}){	    				
								$l_edos_encontrados=$l_edos_encontrados."\t".$arr_edos[$i]."-".$arr_edos_name[$i];
								print $arr_edos_name[$i];
								$texto =~ s/$arr_edos_name[$i]/ /g;
								#print $texto;
								$l_edos_encontrados_cod=$l_edos_encontrados_cod."\t".$arr_edos[$i];
								$hash1{$arr_edos[$i]}="ok";
							}
						}
						$l_edos_encontrados =~ s/\\//g;
						
						$l_mpos_encontrados="";
						$l_mpos_encontrados_cod="";
						my %hash1 = ();
						for ($i=0; $i<$i_mpos; $i++){
							#$l_mpos_encontrados=$l_mpos_encontrados."|".$l_cod{$arr_mpos[$i]};
							if (! exists $municipiosHash1{$arr_mpos[$i]}){
								$municipiosEncontrados = $municipiosEncontrados."\t".$arr_mpos[$i]."-".$arr_mpos_name[$i];
								$texto =~ s/$arr_mpos_name[$i]/ /g;
								$municipiosCodEncontrados = $municipiosCodEncontrados."\t".$arr_mpos[$i];
								$municipiosHash1{$arr_mpos[$i]}="ok";
							}
							if (! exists $hash1{$arr_mpos[$i]}){	    				
								$l_mpos_encontrados=$l_mpos_encontrados."\t".$arr_mpos[$i]."-".$arr_mpos_name[$i];
								$texto =~ s/$arr_mpos_name[$i]/ /g;
								$l_mpos_encontrados_cod=$l_mpos_encontrados_cod."\t".$arr_mpos[$i];
								$hash1{$arr_mpos[$i]}="ok";
							}
						}
						#$l_mpos_encontrados =~ s/
						
						#Verifico si centro aparece solo en tabasco
						for ($i=0; $i<$i_mpos; $i++){
	    				#excepci\u00F3n para centro, mal echa
	     				if (27004 == $arr_mpos[$i]){
								if ($l_edos_encontrados!~/tabasco/i){	
									$arr_mpos[$i]=" ";	$arr_mpos_name[$i]="";  
								}
	    				}
	 					}
	return $l_mpos_encontrados.",".$l_mpos_encontrados_cod.",".$l_edos_encontrados.",".$l_edos_encontrados_cod
}


